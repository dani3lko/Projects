# -*- coding: utf-8 -*-
"""
Created on Sat Feb 25 20:49:10 2023

@author: danie
"""

########################################################################
#   prompt asks user what choice they want
#   user chooses what they want from the options available
#       option 1 goes through diff .txt and reads each line
#       option 2 searching for specific anime needed
#       option 3 quitting the whole program and exiting
#   if user inputs invalid input, starts the program again saying it was wrong
##########################################################################

# seeing if the program can open the file intended to be opened
# If file can not be found, printing statement saying it can't be opened

def open_file():

    while True:

        try:
            filename = input("\nEnter filename: ")
            fp = open(filename, "r", encoding="utf-8")
            return fp

        except FileNotFoundError:
            print("\nFile not found!")

    return filename
            
        
# if the value is greater than max_value then stating a variable and printing what is needed
# if value is less than max_value then to go back to main
    
def find_max(value, name, max_value, max_name):
    
    if value > max_value:
        name = "\n\t{}".format(name)
        return value, name

    elif value < max_value:
        return max_value, max_name
    
    else:
        return value, "{}\n\t{}".format(max_name, name)
    
        
# if num is less than min_num than to state the variable
# if num is greater than min_num to return to main function with what is neccsary 
    
def find_min(num, name, min_num, min_name):

    if num < min_num:
        name = "\n\t{}".format(name)
        return num, name

    elif num > min_num:
        return min_num, min_name
    
    else:
        return num, "{}\n\t{}".format(min_name, name)

# state the different variables needed
# also made counter to count how many times it went throught the code
# "for line in..." going through evert line in the text file
# if score doesn't equal "N/A"
#       run through and say what each vairable means for max and min, then adding counter and result
# if episodes doens't equal "N/A"
#   running through if loop and stating what each variable would be
# if count equals to 0 then to state that the average score will be 0
# after, it will run into a else loop and do the math for finding the average score
# return all variables to the main function

def read_file(data_fp):

    max_score = 0
    max_score_name = ""
    max_episodes = 0
    max_episodes_name = ""
    min_score = 99999999999
    min_score_name = ""

    count = 0
    result = 0.0

    for line in data_fp:
        title = line[0:100].strip()
        score = line[100:105].strip()
        episodes = line[105:110].strip()

        if score != "N/A":
            more_info = find_max(float(score), title, max_score, max_score_name)
            max_score = more_info[0]
            max_score_name = more_info[1]

            min_info_1 = find_min(float(score), title, min_score, min_score_name)
            min_score = min_info_1[0]
            min_score_name = min_info_1[1]

            count += 1
            result += float(score)

        if episodes != 'N/A':
            max_episodes_1 = find_max(int(episodes), title, max_episodes, max_episodes_name)
            max_episodes = max_episodes_1[0]
            max_episodes_name = max_episodes_1[1]

        if count == 0:
            avg_score = 0.0
        else:
            avg_score = result / count
            avg_score = round(avg_score, 2)

    return max_score, max_score_name,  max_episodes, max_episodes_name,min_score, min_score_name, avg_score

# running a for loop and going through every line of code in text file
# for each line, stripping the space in each of them
# if anime_name equals to title than to format in the right space
# returning all the counts    
        
def search_anime(data_fp, anime_name): 
    
    out_string = ''
    count = 0

    for line in data_fp:
        title = line[0:100].strip()
        release_season = line[110:122].strip()

        if anime_name in title:
            out_string += "\n\t{:100s}{:12s}".format(title, release_season)
            count += 1

    return count, out_string




# main function where user inputs which option they desire

def main():
    
    BANNER = "\nAnime-Planet.com Records" \
             "\nAnime data gathered in 2022"
    
    MENU ="Options" + \
          "\n\t1) Get max/min stats" + \
          "\n\t2) Search for an anime" + \
          "\n\t3) Stop the program!" + \
          "\n\tEnter option: "
    
    print(BANNER)
    
    # creating while loop and being able to loop the whole process
    while True:
        choice = input(MENU)
        
        if choice == '3':
            print('\nThank you using this program!')
            break
        
        
        elif choice == '1': 
            filename = open_file()
            
            # these are formating and where the code prints whatever is needed
            # telling user highest score of anime in that .txt
            maxmin = read_file(filename)
            print('\n\nAnime with the highest score of {}:'.format(maxmin[0]))
            print('{}'.format(maxmin[1]))
            
            # telling user what the highest episode count of a specific show is
            print('\n\nAnime with the highest episode count of {:,}:'.format(maxmin[2]))
            print('{}'.format(maxmin[3]))
            
            # telling user what the lowest ranking score of an anime is in that genre of anime
            print('\n\nAnime with the lowest score of {:.2f}:'.format(maxmin[4]))
            print('{}'.format(maxmin[5]))
            
            # telling user avg score of text file
            print('\n\nAverage score for animes in file is {}'.format(maxmin[6]))
            
            filename.close()


        # asking user to input an anime name to search for
        elif choice == '2':
            filename = open_file()
            search = input("\nEnter anime name: ")

            result = search_anime(filename, search)

            # an error telling the use that the anime doesn't exist and asking them to input another one
            if result[0] == 0:
                print("\nNo anime with '{}' was found!".format(search))

            # saying how many anime's there are with the specified amoutn
            else:
                print("\nThere are {} anime titles with '{}'".format(result[0], search))
                print(result[1])

            filename.close()
        
        # if the user doesn't input any of the available option, prompting the user to say valid option
        else:
            if choice != '1' or '2' or '3':
                print('\nInvalid menu option!!! Please try again!')
            

# These two lines allow this program to be imported into other code
# such as our function tests code allowing other functions to be run
# and tested without 'main' running.  However, when this program is
# run alone, 'main' will execute.
#DO NOT CHANGE THESE 2 lines  
if __name__ == "__main__":
    main()